package com.pragim.util;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		TreeSet<Integer> ts = new TreeSet<Integer>();
		ts.add(50);
		ts.add(90);
		ts.add(14);
		ts.add(63);
		ts.add(92);
		ts.add(105);
		ts.add(71);
		
		System.out.println(ts);
		
		

	}

}
